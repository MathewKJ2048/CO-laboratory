
import java.nio.file.Paths;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args) throws Exception {

        //System.out.println("start");
        full_check();
    }
    public static void bin_check() throws Exception
    {
        Scanner sc = new Scanner(System.in);
        while(true)
        {
            String in = sc.next();
            if(in.equals("quit"))break;

            try{
            System.out.println(compiler.Binary.to_binary_unsigned(Integer.parseInt(in),5));
            }
            catch(Exception e)
            {
                System.out.println(e.getMessage());
            }
            try{
                System.out.println(compiler.Binary.to_binary_signed(Integer.parseInt(in),12));
            }
            catch(Exception e)
            {
                System.out.println(e.getMessage());
            }
        }
    }
    public static void full_check()
    {
        compiler.Compiler c = new compiler.Compiler(0,0);
        String error = "";
        try
        {
            c.compile(Paths.get("test.s"),Paths.get("test.bin"));
        }
        catch(Exception e)
        {
            error = "ERROR: "+e.getMessage();
        }
        System.out.println(c.get_transcript());
        System.out.println(error);



        try{processor.Processor.Read(Paths.get("test.bin"));}catch(Exception e){}
        processor.Processor.execute_all();
        for(int i=0;i<32;i++)
        {
            System.out.println("Register x"+i+": "+processor.Processor.get_register(i));
        }
    }
    public static void parse_check()
    {

        compiler.Parser p = new compiler.Parser(" \" a, , bc \" , , \"efg\" ");
        while(p.hasNext())
        {
            try{
                System.out.println("|"+p.next()+"|"+p.start()+"|"+p.end()+"|"+p.is_argument()+"|"+p.is_next_argument());}
            catch(Exception e)
            {
                System.out.println("Exception encountered");
                System.out.println(e.getMessage());
                break;
            }
        }
    }
}
