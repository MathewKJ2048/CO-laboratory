package processor;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.io.*;

public class Processor{
    static Database D = new Database();
    static Instruction_SET I = new Instruction_SET();
    static Extract_Reg R=new Extract_Reg();
    static Operations O = new Operations();
    static int i;

    public static int get_register(int index)
    {
        return D.R[index];
    }
    public static void execute_all()
    {
        for(int j=0;j<(i/4);j=D.PC/4)
        {
            O.IF();
            O.IDRF();
            O.EXE();
        }
    }
    public static void Read(Path binary) throws Exception
    {
        int i=0;
        List<String> l = Files.readAllLines(binary);
        for(String s:l)
        {

            int k= UTIL.toDecimal(s);
            D.InstrMem[i]=(byte)(k>>24);
            D.InstrMem[i+1]=(byte)(k>>16);
            D.InstrMem[i+2]=(byte)(k>>8);
            D.InstrMem[i+3]=(byte)(k);
            i=i+4;
        }
        D.PC=0;
        Processor.i = i;
    }
    public static void clear_registers()
    {
        for(int i=0;i<D.R.length;i++)D.R[i]=0;
    }
}





